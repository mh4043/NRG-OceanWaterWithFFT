In this folder, run npm install
Then run npm start.
File should be hosted on http://localhost:3000/